import { useEffect } from "react"
import Counter from "../../components/Counter/Counter"


const Area = () => {

    const myFunc = () => {
        let promise = new Promise(function (resolve) {
            setTimeout(() => {
                resolve('THIS IS THE RESPONSE MESSAGE')
            }, 5000)
        })
        return promise
    }

    // useEffect(async () => {
    //     myFunc().then(res => {
    //         console.log(res)
    //     })
    // }, [])

    return (
        <div>
            <Counter init_count={0} />
        </div>
    )
}

export default Area